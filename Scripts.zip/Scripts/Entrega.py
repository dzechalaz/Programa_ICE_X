def Entrega(arm):
    import time
    angle_speed = 50
    tcp_speed = 75

    code, digitals = arm.get_cgpio_digital()

    arm.set_servo_angle(angle=[-193.5, -24.7, -0.8, -153.4, 67.8, -12.3], speed=angle_speed,  wait=False, radius=0.0)

    arm.set_position(*[-217.0, 53.5, 213.7, 72.1, 89.3, 152.2], speed=tcp_speed, radius=0.0, wait=False)

    arm.set_servo_angle(angle=[-306.7, -22.1, -5.3, -80.7, 94.6, -25.9], speed=angle_speed,  wait=False, radius=0.0)

    arm.set_position(*[189.4, 87.0, 49.1, 71.3, 89.4, 26.2], speed=tcp_speed, radius=0.0, wait=False)

    arm.set_gripper_position(850, wait=True, speed=5000, auto_enable=True)

    arm.set_position(*[189.8, 87.2, 213.7, 72.1, 89.3, 27.0], speed=tcp_speed, radius=0.0, wait=False)

    arm.set_servo_angle(angle=[-290.5, -45.0, -30.0, -180.0, -45.0, 0.0], speed=angle_speed,  wait=True, radius=0.0)

    if digitals[11] == 1:
        arm.set_cgpio_digital(8, 1, delay_sec=0)

    time.sleep(2)
    
    arm.set_cgpio_digital(8, 0, delay_sec=0)

    arm.set_servo_angle(angle=[-129.4, -45.0, -30.0, -180.0, -45.0, 0.0], speed=angle_speed,  wait=False, radius=0.0)

    arm.set_servo_angle(angle=[0.9, -37.9, -63.5, 0.3, 100.9, 0.2], speed=angle_speed,  wait=True, radius=0.0)

    if digitals[11] == 0:
        arm.set_cgpio_digital(9, 1, delay_sec=0)

    time.sleep(2)
    arm.set_cgpio_digital(9, 0, delay_sec=0)
