def Helado_C_1(arm):
    import time
    # angle_speed = 45
    # arm.set_servo_angle(angle=[-193.5, -24.7, -0.8, -153.4, 67.8, -12.3], speed=angle_speed,  wait=False, radius=0.0)

    # #Esquivar maquina, opisicion incial para cada todos los programas
    # arm.set_servo_angle(angle=[-184.8, -56.6, -0.2, -179.9, 31.1, 0.0], speed=angle_speed,  wait=False, radius=0.0)

    # arm.set_servo_angle(angle=[-135.7, -56.6, -0.2, -179.9, 31.1, 0.0], speed=angle_speed,  wait=False, radius=0.0)

    # arm.set_position(*[-209.5, -388.6, 355.0, -76.6, 87.8, 106.0], speed=angle_speed, radius=0.0, wait=False)

    # arm.set_cgpio_digital(10, 1, delay_sec=0)

    # tcp_speed = 45
    # time.sleep(1)
    # arm.set_position(*[-209.5, -388.6, 355.0, -76.6, 87.8, 106.0], speed=angle_speed, radius=0.0, wait=False)

    # arm.move_circle([-219.5, -398.6, 356.3, -76.6, 87.8, 106.0], [-219.5, -378.6, 356.3, -76.6, 87.8, 106.0], float(630) / 360 * 100, speed=tcp_speed,  wait=False)

    # arm.set_cgpio_digital(10, 0, delay_sec=0)

    # arm.set_cgpio_digital(11, 1, delay_sec=0)

    # arm.set_position(*[-209.5, -388.6, 339.0, -76.6, 87.8, 106.0], speed=tcp_speed,  radius=0.0, wait=False)

    # arm.move_circle([-219.5, -398.6, 339.0, -76.6, 87.8, 106.0], [-219.5, -378.6, 339.0, -76.6, 87.8, 106.0], float(630) / 360 * 100, speed=tcp_speed,  wait=False)

    # arm.set_position(*[-209.5, -388.6, 354.1, -76.6, 87.8, 106.0], speed=tcp_speed,  radius=0.0, wait=False)

    # arm.set_cgpio_digital(11, 0, delay_sec=0)

    # arm.set_position(*[-209.5, -388.6, 304.8, -76.6, 87.8, 106.0], speed=tcp_speed,  radius=0.0, wait=False)

    # angle_speed = 45
    # arm.set_position(*[-154.0, -148.4, 266.0, 176.1, 87.9, 41.7], speed=tcp_speed,  radius=0.0, wait=False)


    angle_speed = 75
    arm.set_servo_angle(angle=[-135.7, -56.6, -0.2, -179.9, 31.1, 0.0], speed=angle_speed, wait=False, radius=0.0)
    tcp_speed = 80
    arm.set_position(*[-216.6, -342.2, 369.2, -76.6, 87.8, 106.0], speed=tcp_speed,  radius=0.0, wait=True)
    arm.set_cgpio_digital(14, 1, delay_sec=0)
    arm.set_cgpio_digital(4, 1, delay_sec=0)
    tcp_speed = 15
    arm.set_position(*[-216.6, -342.2, 335.0, -76.6, 87.8, 106.0], speed=tcp_speed,  radius=0.0, wait=True)
    arm.set_cgpio_digital(14, 0, delay_sec=0)
    tcp_speed = 35
    arm.set_cgpio_digital(15, 1, delay_sec=0)
    arm.set_cgpio_digital(4, 0, delay_sec=0)
    arm.set_position(*[-211.2, -342.2, 335.8, -76.6, 87.8, 106.0], speed=tcp_speed,  radius=0.0, wait=False)
    arm.move_circle([-221.5, -332.3, 335.0, -76.6, 87.8, 106.0], [-221.5, -352.6, 335.3, -76.6, 87.8, 106.0], float(360) / 360 * 100, speed=tcp_speed,  wait=True)
    arm.set_position(*[-211.2, -342.2, 257.5, -76.6, 87.8, 106.0], speed=tcp_speed,  radius=0.0, wait=False)
    tcp_speed = 80
    arm.set_position(*[-154.0, -148.4, 266.0, 176.1, 87.9, 41.7], speed=tcp_speed,  radius=0.0, wait=False)
    time.sleep(4)
    arm.set_cgpio_digital(15, 0, delay_sec=0)