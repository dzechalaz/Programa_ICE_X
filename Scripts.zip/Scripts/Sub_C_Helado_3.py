def Helado_C_3(arm):
    import time    
    # angle_speed = 35
    # arm.set_servo_angle(angle=[-215.7, -30.4, -4.5, -179.9, 52.2, 0.0], speed=angle_speed,  wait=False, radius=0.0)
    
    # arm.set_servo_angle(angle=[-184.8, -56.6, -0.2, -179.9, 31.1, 0.0], speed=angle_speed,  wait=False, radius=0.0)
    
    # arm.set_servo_angle(angle=[-135.7, -56.6, -0.2, -179.9, 31.1, 0.0], speed=angle_speed,  wait=False, radius=0.0)
    
    # arm.set_servo_angle(angle=[-153.6, -49.2, -15.1, -218.6, 32.7, 30.8], speed=angle_speed,  wait=False, radius=0.0)
    
    # arm.set_cgpio_digital(14, 1, delay_sec=0)

    # tcp_speed = 25
    # time.sleep(1)
    # arm.set_position(*[-360.0, -237.2, 355.9, -82.7, 86.5, 144.5], speed=tcp_speed,  radius=0.0, wait=False)

    # arm.move_circle([-370.0, -247.2, 356.3, -81.8, 86.5, 145.4], [-370.0, -227.2, 356.3, -81.8, 86.5, 145.4], float(630) / 360 * 100, speed=tcp_speed,  wait=False)

    # arm.set_cgpio_digital(14, 0, delay_sec=0)

    # arm.set_cgpio_digital(15, 1, delay_sec=0)

    # arm.set_position(*[-360.0, -237.2, 345.0, -82.7, 86.5, 144.5], speed=tcp_speed,  radius=0.0, wait=False)

    # arm.move_circle([-370.0, -247.2, 345.0, -81.8, 86.5, 145.4], [-370.0, -227.2, 345.0, -81.8, 86.5, 145.4], float(630) / 360 * 100, speed=tcp_speed,  wait=False)

    # arm.set_position(*[-360.0, -237.2, 355.9, -82.7, 86.5, 144.5], speed=tcp_speed,  radius=0.0, wait=False)

    # arm.set_cgpio_digital(15, 0, delay_sec=0)

    # arm.set_position(*[-360.0, -237.2, 355.9, -82.7, 86.5, 144.5], speed=tcp_speed,  radius=0.0, wait=False)

    # tcp_speed = 35
    # arm.set_servo_angle(angle=[-135.7, -56.6, -0.2, -179.9, 31.1, -3.5], speed=angle_speed,  wait=False, radius=0.0)

    angle_speed = 75
    arm.set_servo_angle(angle=[-135.7, -56.6, -0.2, -179.9, 31.1, 0.0], speed=angle_speed, wait=False, radius=0.0)
    tcp_speed = 80
    arm.set_position(*[-216.6, -215.7, 369.2, -76.6, 87.8, 106.0], speed=tcp_speed,  radius=0.0, wait=True)
    arm.set_cgpio_digital(11, 1, delay_sec=0)
    arm.set_cgpio_digital(4, 1, delay_sec=0)
    tcp_speed = 15
    arm.set_position(*[-216.6, -215.7, 335.0, -76.6, 87.8, 106.0], speed=tcp_speed,  radius=0.0, wait=True)
    arm.set_cgpio_digital(11, 0, delay_sec=0)
    tcp_speed = 35
    arm.set_cgpio_digital(12, 1, delay_sec=0)
    arm.set_cgpio_digital(4, 0, delay_sec=0)
    arm.set_position(*[-211.2, -215.7, 335.8, -76.6, 87.8, 106.0], speed=tcp_speed,  radius=0.0, wait=False)
    arm.move_circle([-221.5, -205.7, 335.0, -76.6, 87.8, 106.0], [-221.5, -225.7, 335.3, -76.6, 87.8, 106.0], float(360) / 360 * 100, speed=tcp_speed,  wait=True)
    arm.set_position(*[-211.2, -215.7, 257.5, -76.6, 87.8, 106.0], speed=tcp_speed,  radius=0.0, wait=False)
    tcp_speed = 80
    arm.set_position(*[-154.0, -148.4, 266.0, 176.1, 87.9, 41.7], speed=tcp_speed,  radius=0.0, wait=False)
    time.sleep(4)
    arm.set_cgpio_digital(12, 0, delay_sec=0)
