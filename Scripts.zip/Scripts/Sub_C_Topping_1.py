def Topping_C_1(arm):
    import time
    # angle_speed = 35
    # arm.set_servo_angle(angle=[-135.7, -56.6, -0.2, -179.9, 31.1, 0.0], speed=angle_speed,  wait=False, radius=0.0)

    # arm.set_servo_angle(angle=[-184.8, -56.6, -0.2, -179.9, 31.1, 0.0], speed=angle_speed,  wait=False, radius=0.0)

    # arm.set_servo_angle(angle=[-193.5, -24.7, -0.8, -153.4, 67.8, -12.3], speed=angle_speed,  wait=False, radius=0.0)

    # arm.set_position(*[-356.4, -23.1, 238.3, -53.3, 88.4, 90.4], speed=angle_speed, radius=0.0, wait=False)

    # arm.set_position(*[-356.4, -23.1, 303.1, -53.3, 88.4, 90.4], speed=angle_speed,radius=0.0, wait=True)

    # arm.set_cgpio_digital(1, 1, delay_sec=0)
    
    # time.sleep(0.2)

    # arm.set_cgpio_digital(1, 0, delay_sec=0)
    
    # arm.set_position(*[-356.4, -23.1, 238.3, -53.3, 88.4, 90.4], speed=angle_speed, radius=0.0, wait=False)

    # arm.set_servo_angle(angle=[-193.5, -24.7, -0.8, -153.4, 67.8, -12.3], speed=angle_speed,  wait=True, radius=0.0)


    angle_speed = 30
    arm.set_servo_angle(angle=[-191.3, -12.4, -1.6, -152.6, 78.5, -7.6], speed=angle_speed, wait=False, radius=0.0)

    tcp_speed = 70
    arm.set_position(*[-356.4, -23.1, 169.3, -53.3, 88.4, 90.4], speed=tcp_speed, radius=0.0, wait=False)

    arm.set_position(*[-356.4, -23.1, 283.4, -53.3, 88.4, 90.4], speed=tcp_speed, radius=0.0, wait=True)

    arm.set_cgpio_digital(0, 1, delay_sec=0)

    time.sleep(0.2)
    arm.set_cgpio_digital(0, 0, delay_sec=0)

    arm.set_position(*[-356.4, -23.1, 238.3, -54.0, 88.4, 89.7], speed=tcp_speed, radius=0.0, wait=False)

    arm.set_position(*[-227.7, 82.9, 169.3, -54.0, 88.4, 89.7], speed=tcp_speed, radius=0.0, wait=False)
