def Sub_Entrega_V(arm):
    import time
    angle_speed = 50
    tcp_speed = 75
    arm.set_servo_angle(angle=[-191.3, -12.4, -1.6, -152.6, 78.5, -7.6], speed=angle_speed,  wait=False, radius=0.0)
    
        
    arm.set_position(*[-217.0, 53.5, 213.7, 72.1, 89.3, 152.2], speed=tcp_speed,  radius=0.0, wait=False)
    
        
    arm.set_servo_angle(angle=[-326.7, 12.5, -35.4, -70.8, 99.1, -20.5], speed=angle_speed,  wait=False, radius=0.0)
    
        
    arm.set_position(*[310.7, 80.4, 73.9, 22.3, 88.2, -53.8], speed=tcp_speed,  radius=0.0, wait=False)
    
        
    arm.set_gripper_position(850, wait=True, speed=1000, auto_enable=True)
    
        
    arm.set_position(*[280.1, 192.7, 75.9, 22.3, 88.2, -53.8], speed=tcp_speed,  radius=0.0, wait=False)
    
        
    arm.set_servo_angle(angle=[-271.8, 15.3, -26.7, -57.5, 97.7, -8.4], speed=angle_speed,  wait=False, radius=0.0)
    
        
    arm.set_servo_angle(angle=[-288.2, -26.3, -5.8, -119.4, 50.1, -18.0], speed=angle_speed,  wait=False, radius=0.0)
    
        
    arm.set_servo_angle(angle=[-290.5, -45.0, -30.0, -180.0, -45.0, 0.0], speed=angle_speed,  wait=True, radius=0.0)
    
        
    time.sleep(1.5)
    arm.set_servo_angle(angle=[-129.4, -45.0, -30.0, -180.0, -45.0, 0.0], speed=angle_speed,  wait=False, radius=0.0)
    
        
    arm.set_servo_angle(angle=[0.9, -37.9, -63.5, 0.3, 100.9, 0.2], speed=angle_speed,  wait=True, radius=0.0)
    
        
    time.sleep(1.5)