def Cono_2(arm):

    speed = 60
    angle_speed =60

    pos_acual_tub = ()
    pos_acual_tub = arm.get_servo_angle(servo_id=1,is_radian=False)
    pos_actual = pos_acual_tub[1]

    if arm.get_position(is_radian=False) == (0, [262.4151, 2.432852, 570.889648, 178.586934, -0.537205, 1.039804]):
       arm.set_servo_angle(angle=[0.9, -37.9, -63.5, 0.3, 100.9, 0.2], speed=angle_speed,  wait=False, radius=0.0)

    else:
       arm.set_servo_angle(angle=[pos_acual_tub[1], -45.0, -30.0, -180.0, -45.0, 0.0], speed=angle_speed,  wait=False, radius=0.0)
       arm.set_servo_angle(angle=[-129.4, -45.0, -30.0, -180.0, -45.0, 0.0], speed=angle_speed,  wait=False, radius=0.0)
       arm.set_servo_angle(angle=[0.9, -37.9, -63.5, 0.3, 100.9, 0.2], speed=angle_speed,  wait=False, radius=0.0)
        

   #  arm.set_gripper_position(850, wait=False, speed=5000, auto_enable=True)

   #  arm.set_servo_angle(angle=[-129.4, -45.0, -30.0, -180.0, -45.0, 0.0], speed=speed,  wait=False, radius=0.0)

   #  arm.set_servo_angle(angle=[-214.5, -45.0, -30.0, -180.0, -45.0, 0.0], speed=speed,  wait=False, radius=0.0)

   #  arm.set_servo_angle(angle=[-193.5, -24.7, -0.8, -153.4, 67.8, -12.3], speed=speed,  wait=False, radius=0.0)

   #  arm.set_servo_angle(angle=[-229.1, -24.8, -1.5, -170.1, 64.1, -7.5], speed=speed,  wait=False, radius=0.0)

   #  speed = 60

   #  arm.set_position(*[-153.6, 192.3, 326.0, -88.1, 86.8, 35.5], speed=speed,  radius=0.0, wait=False)

   #  arm.set_gripper_position(15, wait=True, speed=5000, auto_enable=True)

   #  arm.set_position(*[-153.7, 192.2, 199.8, -88.4, 86.8, 35.3], speed=speed,  radius=0.0, wait=False)

   #  speed = 60
   #  arm.set_servo_angle(angle=[-193.5, -24.7, -0.8, -153.4, 67.8, -12.3], speed=speed,  wait=False, radius=0.0)



    tcp_speed = 100
    angle_speed = 60

    arm.set_gripper_position(850, wait=True, speed=5000, auto_enable=True)
    arm.set_servo_angle(angle=[-129.4, -45.0, -30.0, -180.0, -45.0, 0.0], speed=angle_speed,  wait=False, radius=0.0)
    arm.set_servo_angle(angle=[-214.5, -45.0, -30.0, -180.0, -45.0, 0.0], speed=angle_speed,  wait=False, radius=0.0)
    arm.set_servo_angle(angle=[-193.5, -24.7, -0.8, -153.4, 67.8, -12.3], speed=angle_speed,  wait=False, radius=0.0)
    arm.set_servo_angle(angle=[-228.1, -21.7, -1.3, -167.1, 68.4, -5.1], speed=angle_speed,  wait=False, radius=0.0)
    angle_speed = 10
    arm.set_position(*[-153.6, 192.3, 326.0, -8.9, 89.1, 112.7], speed=tcp_speed,  radius=0.0, wait=False)
    arm.set_gripper_position(55, wait=True, speed=5000, auto_enable=True)
    arm.set_position(*[-153.6, 192.3, 186.2, -8.9, 89.1, 112.7], speed=tcp_speed,  radius=0.0, wait=False)
    angle_speed = 30
    arm.set_servo_angle(angle=[-193.5, -24.7, -0.8, -153.4, 67.8, -12.3], speed=angle_speed,  wait=False, radius=0.0)