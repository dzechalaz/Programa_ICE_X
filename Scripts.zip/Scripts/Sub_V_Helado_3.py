def Sub_V_Helado_3(arm):
    import time

    angle_speed = 75
    arm.set_cgpio_digital(11, 1, delay_sec=0)
    
        
    arm.set_servo_angle(angle=[-193.5, -24.7, -0.8, -153.4, 67.8, -12.3], speed=angle_speed,  wait=False, radius=0.0)
    
        
    arm.set_servo_angle(angle=[-184.8, -56.6, -0.2, -179.9, 31.1, 0.0], speed=angle_speed,  wait=False, radius=0.0)
    
        
    arm.set_servo_angle(angle=[-135.7, -56.6, -0.2, -179.9, 31.1, 0.0], speed=angle_speed,  wait=False, radius=0.0)
    
        
    time.sleep(5)
    tcp_speed = 125
    arm.set_position(*[-261.2, -234.9, 320.4, -76.6, 87.8, 106.0], speed=tcp_speed,  radius=0.0, wait=True)
    
        
    arm.set_cgpio_digital(11, 0, delay_sec=0)
    
        
    arm.set_position(*[-261.2, -234.9, 337.9, -76.6, 87.8, 106.0], speed=tcp_speed,  radius=0.0, wait=True)
    
        
    arm.set_cgpio_digital(4, 1, delay_sec=0)
    
        
    arm.set_cgpio_digital(12, 1, delay_sec=0)
    
        
    time.sleep(1)
    arm.set_cgpio_digital(4, 0, delay_sec=0)
    
        
    tcp_speed = 35
    arm.set_position(*[-261.2, -235.0, 318.5, -76.6, 87.8, 106.0], speed=tcp_speed,  radius=0.0, wait=False)
    
        
    arm.set_position(*[-240.674658, -226.5809458, 320.0, -76.6, 87.8, 106.0], speed=tcp_speed,  radius=0.0, wait=False)
    
        
    arm.set_position(*[-245.4436794, -219.4436222, 320.0, -76.6, 87.8, 106.0], speed=tcp_speed,  radius=0.0, wait=False)
    
        
    arm.set_position(*[-252.5810205, -214.6746271, 320.0, -76.6, 87.8, 106.0], speed=tcp_speed,  radius=0.0, wait=False)
    
        
    arm.set_position(*[-261.0000808, -213.0, 320.0, -76.6, 87.8, 106.0], speed=tcp_speed,  radius=0.0, wait=False)
    
        
    arm.set_position(*[-269.4191288, -214.6746889, 320.0, -76.6, 87.8, 106.0], speed=tcp_speed,  radius=0.0, wait=False)
    
        
    arm.set_position(*[-276.5564349, -219.4437365, 320.0, -76.6, 87.8, 106.0], speed=tcp_speed,  radius=0.0, wait=False)
    
        
    arm.set_position(*[-281.3254038, -226.5810951, 320.0, -76.6, 87.8, 106.0], speed=tcp_speed,  radius=0.0, wait=False)
    
        
    arm.set_position(*[-283.0, -235.0001616, 320.0, -76.6, 87.8, 106.0], speed=tcp_speed,  radius=0.0, wait=False)
    
        
    arm.set_position(*[-281.3252801, -243.4192035, 320.0, -76.6, 87.8, 106.0], speed=tcp_speed,  radius=0.0, wait=False)
    
        
    arm.set_position(*[-276.5562063, -250.556492, 320.0, -76.6, 87.8, 106.0], speed=tcp_speed,  radius=0.0, wait=False)
    
        
    arm.set_position(*[-269.4188302, -255.3254348, 320.0, -76.6, 87.8, 106.0], speed=tcp_speed,  radius=0.0, wait=False)
    
        
    arm.set_position(*[-260.9997576, -257.0, 320.0, -76.6, 87.8, 106.0], speed=tcp_speed,  radius=0.0, wait=False)
    
        
    arm.set_position(*[-252.5807218, -255.3252492, 320.0, -76.6, 87.8, 106.0], speed=tcp_speed,  radius=0.0, wait=False)
    
        
    arm.set_position(*[-245.4434508, -250.5561492, 320.0, -76.6, 87.8, 106.0], speed=tcp_speed,  radius=0.0, wait=False)
    
        
    arm.set_position(*[-240.6745343, -243.4187555, 320.0, -76.6, 87.8, 106.0], speed=tcp_speed,  radius=0.0, wait=False)
    
        
    arm.set_position(*[-239.0, -234.9996768, 320.0, -76.6, 87.8, 106.0], speed=tcp_speed,  radius=0.0, wait=False)
    
        
    arm.set_position(*[-262.1, -234.9, 320.0, -76.6, 87.8, 106.0], speed=tcp_speed,  radius=0.0, wait=False)
    
        
    arm.set_position(*[-262.1, -234.9, 266.4, -76.6, 87.8, 106.0], speed=tcp_speed,  radius=0.0, wait=False)
    
        
    arm.set_position(*[-262.1, -234.9, 315.5, -76.6, 87.8, 106.0], speed=tcp_speed,  radius=0.0, wait=False)
    
        
    arm.set_position(*[-237.4, -234.9, 257.3, -76.6, 87.8, 106.0], speed=tcp_speed,  radius=0.0, wait=False)
    
        
    tcp_speed = 80
    arm.set_position(*[-154.0, -148.4, 266.0, 176.1, 87.9, 41.7], speed=tcp_speed,  radius=0.0, wait=False)
    
        
    time.sleep(4)
    arm.set_cgpio_digital(12, 0, delay_sec=0)
            
                