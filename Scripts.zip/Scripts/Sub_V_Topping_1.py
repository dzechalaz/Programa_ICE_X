def Topping_V_1(arm):
    import time
    angle_speed = 30
    code = arm.set_servo_angle(angle=[-191.3, -12.4, -1.6, -152.6, 78.5, -7.6], speed=angle_speed, wait=False, radius=0.0)
    tcp_speed = 70
    code = arm.set_position(*[-380.0, 50.2, 169.0, -53.3, 88.4, 104.3], speed=tcp_speed,  radius=0.0, wait=False)
    code = arm.set_position(*[-380.0, 50.2, 245.3, -53.3, 88.4, 104.3], speed=tcp_speed,  radius=0.0, wait=True)
    code = arm.set_cgpio_digital(0, 1, delay_sec=0)
    time.sleep(0.2)
    code = arm.set_cgpio_digital(0, 0, delay_sec=0)
    code = arm.set_position(*[-380.0, 50.2, 169.0, -53.3, 88.4, 104.3], speed=tcp_speed,  radius=0.0, wait=False)
    code = arm.set_position(*[-227.7, 82.9, 169.3, -54.0, 88.4, 89.7], speed=tcp_speed,  radius=0.0, wait=False)
