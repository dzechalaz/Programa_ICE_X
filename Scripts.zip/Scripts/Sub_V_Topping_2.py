def Topping_V_2(arm):
    import time
    angle_speed = 30
    arm.set_servo_angle(angle=[-191.3, -12.4, -1.6, -152.6, 78.5, -7.6], speed=angle_speed,  wait=False, radius=0.0)
    tcp_speed = 70
    arm.set_position(*[-235.2, 205.7, 169.0, -53.3, 88.4, 90.4], speed=tcp_speed,  radius=0.0, wait=False)
    arm.set_position(*[-235.2, 205.7, 231.2, -53.3, 88.4, 90.4], speed=tcp_speed,  radius=0.0, wait=True)
    arm.set_cgpio_digital(2, 1, delay_sec=0)
    time.sleep(0.2)
    arm.set_cgpio_digital(2, 0, delay_sec=0)
    arm.set_position(*[-235.2, 205.7, 169.0, -53.3, 88.4, 90.4], speed=tcp_speed,  radius=0.0, wait=False)
    
    arm.set_position(*[-227.7, 82.9, 169.3, -54.0, 88.4, 89.7], speed=tcp_speed,  radius=0.0, wait=False)
    